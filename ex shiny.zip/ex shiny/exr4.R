library(shiny)
library(datasets)
library(psych)

ui <- fluidPage(
  
  selectInput("dataset", "Select a dataset", choices = ls("package:datasets")),
  
  verbatimTextOutput("summary"),
  
  tableOutput("head")
  
)

server <- function(input, output) {

  dataset <- reactive({
    get(input$dataset, "package:datasets") 
  })
  
  output$head <- renderTable({
    head(dataset(), 10)
  })
  
  output$summary <- renderPrint({
    cat("Summary Statistics:\n")
    print(describe(dataset()))
    
    cat("\nSummary by Categorical Variables:\n")
    categorical <- sapply(dataset(), function(x) length(unique(x)) < 10)
    print(describeBy(dataset(), which(categorical)))
  })
  
}

shinyApp(ui, server)