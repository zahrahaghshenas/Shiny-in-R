library(shiny)
library(psych)

# Define the UI
ui <- fluidPage(
  selectInput("dataset", label = "Dataset", choices = ls("package:datasets")),
  verbatimTextOutput("summary"),
  tableOutput("table")
)

# Define the server
server <- function(input, output, session) {
  
  output$summary <- renderPrint({
    dataset <- get(input$dataset, "package:datasets")
    summary(dataset)
  })
  
  output$table <- renderTable({
    dataset <- get(input$dataset, "package:datasets")
    dataset
  })
  
  output$categorical <- renderPrint({
    dataset <- get(input$dataset, "package:datasets")
    categorical_vars <- sapply(dataset, is.factor)
    categorical_summary <- describeBy(dataset[, categorical_vars], dataset[, categorical_vars], mat = TRUE)
    categorical_summary
  })
  
}

# Run the Shiny app
shinyApp(ui = ui, server = server)